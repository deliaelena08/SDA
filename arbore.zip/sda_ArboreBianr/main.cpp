
//REprezentarea sub forma unei matrici rare triplete de forma <linie,cooana,valoare>
//memorate folosind abc inlatuit cu alocare dinamica
#include <iostream>
#include "Matrice.h"
#include "TestExtins.h"
#include "TestScurt.h"

using namespace std;


int main() {
    cout<<"Test cerinta noua"<<endl;
    testIterator();
    cout<<"Test scurt"<<endl;
	testAll();
    cout<<"Test extins"<<endl;
	testAllExtins();
    cout<<"End";
}
