#pragma once

void testAll();
void testIterator();