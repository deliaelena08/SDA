#pragma once

void testAll();
void testFunctionalitate();