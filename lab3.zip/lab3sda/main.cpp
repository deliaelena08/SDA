#include <iostream>
#include "TestExtins.h"
#include "TestScurt.h"
using namespace std;


int main() {
    cout<<"Test scurt"<<endl;
	testAll();
    cout<<"Test functionalitate:";
    testNouafunctionalitate();
    cout<<"Test extins: ";
	testAllExtins();
    cout<<endl<<"All passed";

}
