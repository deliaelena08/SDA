#pragma once

void testAll();
void testNouafunctionalitate();