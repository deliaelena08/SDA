#include "TestScurt.h"
#include "MD.h"
#include "IteratorMD.h"
#include <assert.h>
#include <vector>
#include<iostream>

void testAll() {
    MD m;
    m.adauga(1, 100);
    m.adauga(2, 200);
    m.adauga(3, 300);
    m.adauga(1, 500);
    m.adauga(2, 600);
    m.adauga(4, 800);
    assert(m.dim() == 6);

    assert(m.sterge(5, 600) == false);
    assert(m.sterge(1, 500) == true);

    assert(m.dim() == 5);

    vector<TValoare> v;
    v=m.cauta(6);
    assert(v.size()==0);

    v=m.cauta(1);
    assert(v.size()==1);

    assert(m.vid() == false);

    IteratorMD im = m.iterator();
    assert(im.valid() == true);
    while (im.valid()) {
        im.element();
        im.urmator();
    }
    assert(im.valid() == false);
    im.prim();
    assert(im.valid() == true);
}


bool conditiePrim(TValoare val){
    if(val<=1)
        return false;
    if(val%2==0)
        return false;
    for(int d=3;d*d<=val;d+=2){
        if(val%d==0)
            return false;
    }
    return true;
}

void testFiltrare(){
    MD m;
    m.adauga(1, 10);
    m.adauga(2, 21);
    m.adauga(3, 3);
    m.adauga(5, 5);
    m.adauga(3, 17);
    m.adauga(4, 80);
    assert(m.dim() == 6);
    m.filtreaza( conditiePrim);
    assert(m.dim()==3);

    MD m2;
    for(int i=1;i<=100;i++)
        m2.adauga(i,i);
    assert(m2.dim()==100);
    m2.filtreaza(conditiePrim);
    assert(m2.dim()==24);
}