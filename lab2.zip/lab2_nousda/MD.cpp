#include "MD.h"
#include "IteratorMD.h"
#include <exception>
#include <iostream>

using namespace std;


MD::MD() {
    prim= NULL;
    ultim= NULL;
    size=0;
}


void MD::adauga(TCheie c, TValoare v) {
    //Theta(1)
    nodCheie* cheie=prim;
    if(prim==NULL){
        size=1;
        cheie=new nodCheie;
        cheie->cheie=c;
        cheie->valoare=v;
        cheie->urmator=NULL;

        prim=cheie;
        ultim=cheie;
        return;
    }

    nodCheie* nou_cheie=new nodCheie;
    nou_cheie->cheie=c;
    nou_cheie->valoare=v;
    nou_cheie->urmator=nullptr;

    ultim->urmator=nou_cheie;
    nou_cheie->prev=ultim;
    ultim=nou_cheie;
    size++;
}


bool MD::sterge(TCheie c, TValoare v) {
    //Theta(n)
    nodCheie* i=prim;
    while(i!=NULL) {
        nodCheie* u=i->urmator;
        if(i->cheie==c && i->valoare==v){
            if(size==1){
                ultim=NULL;
                prim=NULL;
            }
            else if(i==prim){
                    nodCheie* aux=i->urmator;
                    aux->prev=NULL;
                    prim=aux;
                }
                else if(i==ultim){
                        nodCheie* aux=i->prev;
                        aux->urmator=NULL;
                        ultim=aux;
                    }
                    else {
                        nodCheie *aux1 = i->urmator;
                        nodCheie *aux2 = i->prev;
                        aux1->prev = aux2;
                        aux2->urmator = aux1;
                    }
                delete(i);
                size--;
                return true;
        }
        i = u;
    }
    return false;
}

vector<TValoare> MD::cauta(TCheie c) const {
    //O(n)
    nodCheie* i=prim;
    vector <TValoare> list;
    while(i!=NULL){
        if(i->cheie==c)
            list.push_back(i->valoare);
        i=i->urmator;
    }
    return list;
}


int MD::dim() const {
    //Theta(1)
    return size;
}


bool MD::vid() const {
    //Theta(1)
    return prim==NULL;
}

IteratorMD MD::iterator() const {
    //Theta(1)
    return IteratorMD(*this);
}


MD::~MD() {
    //Theta(n)
    nodCheie* n=prim;
    while(n!=NULL){
        nodCheie* aux=n->urmator;
        delete n;
        n=aux;
    }
}

void MD::filtreaza(Conditie cond){
    //Theta(n^2)
    nodCheie* n=prim;
    while(n!=NULL){
        nodCheie* aux=n->urmator;
        if(!cond(n->valoare))
            sterge(n->cheie,n->valoare);
        n=aux;
    }
}

