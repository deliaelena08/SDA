#include "IteratorMD.h"
#include "MD.h"
#include<exception>

using namespace std;

IteratorMD::IteratorMD(const MD& _md): md(_md) {
    //Theta(1)
   curent=md.prim;
}

TElem IteratorMD::element() const{
    //Theta(1)
    if(!valid())
        throw exception();
    TElem c;
    c.first=curent->cheie;
    c.second=curent->valoare;
    return c;
}

bool IteratorMD::valid() const {
    //Theta(1)
    return curent!=NULL;
}

void IteratorMD::urmator() {
    //Theta(1)
    if(valid())
        curent=curent->urmator;
    else
        throw exception();
}

void IteratorMD::prim() {
    //Theta(1)
    curent=md.prim;
}

