#pragma once

void testAllExtins();