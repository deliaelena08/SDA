#include <iostream>
#include "TestExtins.h"
#include "TestScurt.h"

using namespace std;



int main() {
    testFiltrare();
    cout<<"Test Functionalitate\n";
    testAll();
    cout<<"Test Scurt"<<'\n';
    testAllExtins();
    cout<<"End";
}
