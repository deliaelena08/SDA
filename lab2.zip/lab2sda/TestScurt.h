#pragma once


void testAll();
void testFiltrare();
