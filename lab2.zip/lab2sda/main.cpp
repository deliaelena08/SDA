#include <iostream>
#include "TestExtins.h"
#include "TestScurt.h"

using namespace std;



int main() {

	testAll();
    cout<<"Test scurt"<<'\n';
    testFiltrare();
    cout<<"Test filtrare"<<'\n';
	testAllExtins();
    cout<<"Test extins"<<'\n';

	cout<<"End";

}
