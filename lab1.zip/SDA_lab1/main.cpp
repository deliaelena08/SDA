#include <iostream>
#include "Coada.h"
#include "TestExtins.h"
#include "TestScurt.h"
using namespace std;


int main() {
	testAll();
	testAllExtins();
    cout<<"All passed:)"<<'\n';
    int v[10];
    v[]={1};
    for(int i=1;i<=10;i++)
        cout<<v[i]<<' ';
}
