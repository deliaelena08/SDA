
#include "Coada.h"
#include <exception>
#include <iostream>
#include <limits.h>

using namespace std;


Coada::Coada() {
	/* de adaugat */
    cp = 10;
    final=0;
    array = new TElem[cp];
    inceput=0;
}


void Coada::adauga(TElem elem) {
    if(final+1>cp && (final+1==inceput or inceput==0))
    {
        TElem* aux;
        aux=new TElem [cp*2];
        for(int i=inceput;i<final;i++)
            aux[i]=array[i];
        free(array);
        cp=cp*2;
        array=aux;
    }
    else
        if(final+1>cp or inceput!=0)
            final=0;

    array[final] = elem;
    final ++;
}

//arunca exceptie daca coada e vida
TElem Coada::element() const {
    if (final == 0) {
        throw exception();
    }
	return array[inceput];
}

TElem Coada::sterge() {
    if (final == 0) {
        throw exception();
    }
    TElem elem = array[inceput];
    inceput=inceput+1;
	return elem;
}

bool Coada::vida() const {
	/* de adaugat */
	return final == inceput;
}


Coada::~Coada() {
	/* de adaugat */
    delete [] array;
}

//transformati intr o coada cu capacitate fixa /constructorul clasei primeste ca parametru un numar intreg care e capacitatea/adaugarea va arunca fals daca e plina